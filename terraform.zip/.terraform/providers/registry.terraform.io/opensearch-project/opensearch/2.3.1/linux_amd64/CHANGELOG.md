# Changelog
## Unreleased
### Changed

### Added

### Fixed

## [1.0.0] - 2023-04-15
### Added
* Release 1.0 based on phillbaker/terraform-provider-elasticsearch
